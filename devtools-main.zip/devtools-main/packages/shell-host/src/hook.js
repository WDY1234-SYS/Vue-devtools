import { installHook } from '@back/hook'

installHook(window)
