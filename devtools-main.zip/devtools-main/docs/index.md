---
home: true
sidebar: false
heroImage: /logo.svg

actionText: Get Started
actionLink: /guide/installation

footer: MIT Licensed | Copyright © 2014-present Evan You, Guillaume Chau
---

## Sponsors

[💚️ Become a Sponsor](https://github.com/sponsors/Akryum)

<p align="center">
  <a href="https://guillaume-chau.info/sponsors/" target="_blank">
    <img src='https://akryum.netlify.app/sponsors.svg'/>
  </a>
</p>
