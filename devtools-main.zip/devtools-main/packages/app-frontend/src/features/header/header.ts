import { ref } from '@vue/composition-api'

export const showAppsSelector = ref(true)
