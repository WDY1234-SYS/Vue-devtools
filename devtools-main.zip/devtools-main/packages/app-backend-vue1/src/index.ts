import { defineBackend } from '@vue-devtools/app-backend-api'

export const backend = defineBackend({
  frameworkVersion: 1,
  features: [],
  setup (api) {
    // @TODO
  },
})
